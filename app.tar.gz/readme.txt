vibora v0.1.0
2018年7月22日 7:56:52
62e085535b14edf769a4e83f826fd2cadd0f5678
Merge pull request #148 from danieldaeschle/patch-6
Frank Vieira

基于以上版本编译后: vibora-0.0.7.linux-x86_64.tar.gz
再解压后得到三个目录: tests/ vibora/ vibora-0.0.7-py3.6.egg-info/

nginx:
nginx.tgz 仅包含bin/目录, 内有二进制可执行文件
另外四个目录: conf/ html/ logs/ tmp/